<?php

if (! defined('ABSPATH')) exit;

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://www.wpoven.com
 * @since      1.0.0
 *
 * @package    OvenPress_Triple_Cache
 * @subpackage OvenPress_Triple_Cache/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->